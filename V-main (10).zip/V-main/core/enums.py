from enum import Enum

class StrategyType(Enum):
    WAIT = "WAIT"
    
    # --- INCOME (Defined Risk) ---
    IRON_CONDOR = "IRON_CONDOR"
    IRON_FLY = "IRON_FLY"
    
    # --- AGGRESSIVE INCOME (Undefined Risk) ---
    SHORT_STRANGLE = "SHORT_STRANGLE"
    SHORT_STRADDLE = "SHORT_STRADDLE"
    
    # --- SMART SKEW (Net Credit / No Upside Risk) ---
    JADE_LIZARD = "JADE_LIZARD"             # Sell Put + Sell Call Spread
    REVERSE_JADE_LIZARD = "REVERSE_JADE_LIZARD" # Sell Call + Sell Put Spread
    
    # --- CRASH DEFENSE (Financed Hedges) ---
    RATIO_SPREAD_PUT = "RATIO_SPREAD_PUT"   # Sell 2 OTM, Buy 1 ATM
    RATIO_SPREAD_CALL = "RATIO_SPREAD_CALL"
    
    # --- DIRECTIONAL ---
    BULL_PUT_SPREAD = "BULL_PUT_SPREAD"
    BEAR_CALL_SPREAD = "BEAR_CALL_SPREAD"
    BULL_CALL_SPREAD = "BULL_CALL_SPREAD"
    BEAR_PUT_SPREAD = "BEAR_PUT_SPREAD"
    
    # --- VOLATILITY LONG ---
    LONG_STRADDLE = "LONG_STRADDLE"
    LONG_CALENDAR_CALL = "LONG_CALENDAR_CALL"
    LONG_CALENDAR_PUT = "LONG_CALENDAR_PUT"

class TradeStatus(Enum):
    PENDING = "PENDING"
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    EXTERNAL = "EXTERNAL"
    REJECTED = "REJECTED"

class OrderStatus(Enum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"
    PARTIAL = "PARTIAL"

class ExitReason(Enum):
    PROFIT_TARGET = "PROFIT_TARGET"
    STOP_LOSS = "STOP_LOSS"
    EXPIRY = "EXPIRY"
    CIRCUIT_BREAKER = "CIRCUIT_BREAKER"
    RISK_BREACH = "RISK_BREACH"
    MANUAL = "MANUAL"

class CapitalBucket(Enum):
    WEEKLY = "weekly_expiries"
    MONTHLY = "monthly_expiries"
    INTRADAY = "intraday_adjustments"

class ExpiryType(Enum):
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    INTRADAY = "INTRADAY"

class MarketRegime(Enum):
    EXTREME_FEAR = "EXTREME_FEAR"        # IV Rank > 90
    HIGH_VOL = "HIGH_VOL"                # IV Rank > 60
    NORMAL_VOL = "NORMAL_VOL"
    LOW_VOL = "LOW_VOL"                  # IV Rank < 20
    BINARY_EVENT = "BINARY_EVENT"
    BULL_TREND = "BULL_TREND"
    BEAR_TREND = "BEAR_TREND"
    SAFE = "SAFE"
